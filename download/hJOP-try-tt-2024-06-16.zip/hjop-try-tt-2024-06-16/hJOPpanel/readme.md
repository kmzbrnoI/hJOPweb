Pro spuštění různých panelů stačí programu hJOPpanel v prvním argumentu
předat cestu ke konfiguračnímu souboru stanice. Konfigurační soubory jsou
umístěny v adresáři "panely".

Panely pak lze jednoduše spouštět například za využití zástupců.
