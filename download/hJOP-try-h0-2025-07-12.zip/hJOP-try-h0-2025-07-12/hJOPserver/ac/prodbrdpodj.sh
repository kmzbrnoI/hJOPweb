#!/bin/bash

PYTHONPATH=ac-python python3 brdpodj.py -s 192.168.0.51 -l info 12800 4MvSPnJOc8yj7fzut0JYL9dz9siGlgXq
