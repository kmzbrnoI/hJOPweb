#!/usr/bin/env python3

"""
ASVjC Hrad

Usage:
  hrasvjc.py [options] <block-id> <password>
  hrasvjc.py --version

Options:
  -s <servername>    Specify hJOPserver address [default: localhost]
  -p <port>          Specify hJOPserver port [default: 5896]
  -l <loglevel>      Specify loglevel (python logging package) [default: info]
  -h --help          Show this screen.
  --version          Show version.
"""

import logging
from docopt import docopt  # type: ignore
from typing import List, Dict, Any, Set
import random

import ac
import ac.pt
import ac.blocks
from ac import ACs, AC

JC_IDS = [
    3016, 3017, 3018, 3019, 3020,  # From Hr 1S
    3010, 3009, 3008, 3007, 3006   # From Hr 2L (from Břízky)
]

JC = Dict[str, Any]


class HrASVjCAc(AC):
    def on_start(self) -> None:
        logging.info('Start')
        self.set_color(0x00ff00)

        self.jcs = load_jcs(JC_IDS)
        self.blocks = ac.blocks.dict(state=True)
        self.register_blocks()
        self.process_available_jc()

    def register_blocks(self) -> None:
        track_ids: Set[int] = set()
        for jc in self.jcs.values():
            track_ids = track_ids.union({track for track in jc['tracks']})
            jc['signalTrackId'] = self.blocks[jc['signalId']]['track']
            track_ids.add(jc['signalTrackId'])
        ac.blocks.register_change(self.on_block_change, *track_ids)

    def on_resume(self) -> None:
        self.process_available_jc()

    def jc_available(self, jc: JC) -> bool:
        signal_track = self.blocks[jc['signalTrackId']]['blockState']
        if (signal_track.get('trains', []) == [] and signal_track.get('trainPredict', '') == ''):
            return False

        for track_id in jc['tracks']:
            state = self.blocks[track_id]['blockState']
            if (state['lock'] > 0 or state['state'] != 'free' or
                    state.get('note', '') != '' or state.get('lockout', '') != ''):
                return False
        return True

    def available_jcs(self) -> List[JC]:
        return [jc for jc in self.jcs.values() if self.jc_available(jc)]

    def process_available_jc(self) -> None:
        jcs = self.available_jcs()
        if jcs:
            jc = random.choice(jcs)
            logging.info(f'Processing {jc["name"]}...')

            result = self.pt_put(f'/jc/{jc["id"]}/activate', {})
            if result['success']:
                logging.info('ok')
            else:
                logging.error(f'Unable to process JC {jc["name"]}: ' +
                              str(result['barriers']))

    def on_block_change(self, block: ac.Block) -> None:
        self.blocks[block['id']] = block
        if not self.running():
            return
        self.process_available_jc()


def load_jcs(ids: List[int]) -> Dict[int, JC]:
    return {
        int(jc['id']): jc
        for jc in ac.pt.get('/jc')['jc']
        if int(jc['id']) in ids
    }


if __name__ == '__main__':
    args = docopt(__doc__)

    loglevel = {
        'debug': logging.DEBUG,
        'info': logging.INFO,
        'warning': logging.WARNING,
        'error': logging.ERROR,
        'critical': logging.CRITICAL,
    }.get(args['-l'], logging.INFO)

    logging.basicConfig(level=loglevel)

    ACs[args['<block-id>']] = HrASVjCAc(
        args['<block-id>'], args['<password>']
    )
    ac.init(args['-s'], int(args['-p']))
