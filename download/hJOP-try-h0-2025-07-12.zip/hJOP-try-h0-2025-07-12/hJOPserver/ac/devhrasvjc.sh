#!/bin/bash

PYTHONPATH=ac-python python3 hrasvjc.py -s 192.168.0.51 -l debug 3800 kYbh2SObGYHCfmQjuNZ9yjbDqMjva3zk
