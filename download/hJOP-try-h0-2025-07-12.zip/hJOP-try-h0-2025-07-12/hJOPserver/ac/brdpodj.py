#!/usr/bin/env python3

"""
Automatic PODJ on Brizky-dvoukolejka.

Usage:
  brdpodj.py [options] <block-id> <password>
  brdpodj.py --version

Options:
  -s <servername>    Specify hJOPserver address [default: localhost]
  -p <port>          Specify hJOPserver port [default: 5896]
  -l <loglevel>      Specify loglevel (python logging package) [default: info]
  -h --help          Show this screen.
  --version          Show version.
"""

import logging
from docopt import docopt  # type: ignore
from typing import List

import ac
import ac.blocks
from ac import ACs, AC

TRACKS = {
    'Sk>>BrD 1': 100000,
    'Sk>>BrD 2': 100100,
    'BrD>>Hr 1': 101600,
    'BrD>>Hr 2': 101700,
}
TRACK_DIR_A_TO_B = 1
TRACK_DIR_B_TO_A = 2
RAIL_1 = 12100
RAIL_2 = 12101
PODJ_SIGNALS_TO_CHECK = {
    RAIL_1: 12405,
    RAIL_2: 12406,
}
PODJ_SIGNALS_TO_CHECK_REV = {
    value: key for key, value in PODJ_SIGNALS_TO_CHECK.items()
}


class BrdPodjAC(AC):
    def on_start(self) -> None:
        logging.info('Start')
        self.set_color(0x00ff00)
        self.check_jcs()
        ac.blocks.register_change(
            self.on_block_change, RAIL_1, RAIL_2,
            *PODJ_SIGNALS_TO_CHECK.values()
        )
        self.init_blocks()

    def on_resume(self) -> None:
        self.init_blocks()

    def init_blocks(self) -> None:
        self.on_block_change(ac.pt.get(f'/blocks/{RAIL_1}?state=1')['block'])
        self.on_block_change(ac.pt.get(f'/blocks/{RAIL_2}?state=1')['block'])

    def check_jcs(self) -> None:
        trackstate = {}
        for trackname, trackid in TRACKS.items():
            trackstate[trackname] = ac.pt.get(
                f'/blockState/{trackid}')['blockState']

        if (trackstate['Sk>>BrD 1']['direction'] ==
                trackstate['BrD>>Hr 1']['direction']
                and not trackstate['Sk>>BrD 1']['request']
                and not trackstate['BrD>>Hr 1']['request']):
            if trackstate['Sk>>BrD 1']['direction'] == TRACK_DIR_A_TO_B:
                self.jcs([12002, 12012])
            elif trackstate['Sk>>BrD 1']['direction'] == TRACK_DIR_B_TO_A:
                self.jcs([12000, 12010])


        if (trackstate['Sk>>BrD 2']['direction'] ==
                trackstate['BrD>>Hr 2']['direction']
                and not trackstate['Sk>>BrD 2']['request']
                and not trackstate['BrD>>Hr 2']['request']):
            if trackstate['Sk>>BrD 2']['direction'] == TRACK_DIR_A_TO_B:
                self.jcs([12003, 12013])
            elif trackstate['Sk>>BrD 2']['direction'] == TRACK_DIR_B_TO_A:
                self.jcs([12001, 12011])

    def jcs(self, jcids: List[int]):
        for jcid in jcids:
            self.jc(jcid)

    def jc(self, id_: int) -> None:
        logging.info(f'Processing JC {id_}...')
        result = self.pt_put(f'/jc/{id_}/activate', {'ab': True})
        if result['success']:
            logging.info('ok')
        else:
            logging.error(f'Unable to process JC {id_}: ' +
                          str(result.get('barriers', [])))

    def on_block_change(self, block: ac.Block) -> None:
        if not self.running():
            return
        if block['id'] in PODJ_SIGNALS_TO_CHECK.values():
            blkid = PODJ_SIGNALS_TO_CHECK_REV[block['id']]
            block = ac.pt.get(f'/blocks/{blkid}?state=1')['block']
        if 'trainPredict' not in block['blockState']:
            return
        trainid = block['blockState']['trainPredict']
        train = ac.pt.get(f'/trains/{trainid}')['train']

        if str(block['id']) in train.get('podj', {}):
            return  # PODJ already set

        # TODO: tweak length
        if (train['type'] not in ['Os', 'MOs'] or
                train['length'] == 0 or train['length'] > 150):
            return

        sigid = PODJ_SIGNALS_TO_CHECK[block['id']]
        signal = ac.pt.get(f'/blockState/{sigid}')['blockState']
        if signal['signal'] in [0, 5, 8, 9, 10, 13]:
            return

        result = self.pt_put(f'/trains/{trainid}/podj/{block["id"]}', {
            'podj': {'relative': '00:30'}
        })
        logging.info(f'Done PODJ for train {train["name"]}: {result}')


if __name__ == '__main__':
    args = docopt(__doc__)

    loglevel = {
        'debug': logging.DEBUG,
        'info': logging.INFO,
        'warning': logging.WARNING,
        'error': logging.ERROR,
        'critical': logging.CRITICAL,
    }.get(args['-l'], logging.INFO)

    logging.basicConfig(level=loglevel)
    ACs[args['<block-id>']] = BrdPodjAC(
        args['<block-id>'], args['<password>']
    )
    ac.init(args['-s'], int(args['-p']))
